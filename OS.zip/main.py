import time
import zipfile
import os
print("Server or Client?")
time.sleep(1)
def installserver():
	with zipfile.ZipFile("Server.zip", 'r') as zip_ref: zip_ref.extractall("System")
	os.remove("Server.zip")
	os.remove("Client.zip")
def installclient():
	with zipfile.ZipFile("Client.zip", 'r') as zip_ref: zip_ref.extractall("System")
	os.remove("Server.zip")
	os.remove("Client.zip")
while True:
	termin = input("> ")
	if termin == "server":
		print("Ok!")
		installserver()
		break
	else:
		if termin == "client":
			print("Ok!")
			installclient()
			break
		else:
			print("Invalid.")